package com.duoc.TicketMaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketMasterApplication.class, args);
	}

}
